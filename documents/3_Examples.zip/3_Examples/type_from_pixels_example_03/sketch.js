/**
 * type using pixels of an invisibly draw text to draw a grid of dots 
 *
 * KEYS
 * a-z                  : text input (keyboard)
 * backspace            : delete last typed letter
 * ctrl                 : save png
 */

var textTyped = "ABC";

var font;
var fontSize = 350;
var textImg;

var particles = [];
var particleCount = 10000;

var minDiameter = 4;
var maxDiameter = 20;

var isInside;

function preload() {
  font = loadFont("data/FreeSansBold.ttf");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 255);

  setupText();
  setupParticles();
}

function setupText() {
  // create an offscreen graphics object to draw the text into
  textImg = createGraphics(width, height);
  textImg.pixelDensity(1);
  textImg.background(255);
  textImg.textFont(font);
  textImg.textSize(fontSize)
  textImg.text(textTyped, 100, fontSize + 50);
  textImg.loadPixels();
}

function setupParticles() {
  for (var i = 0; i < particleCount; i++) {
    particles.push({
      x: random(0, width),
      y: random(0, height),
      vy: random(0.5, 2),
      diameter: minDiameter,
      col: color(random(170, 240), 70, 100, 80),
    });
  }
}

function draw() {
  background(0);

  noStroke();


  for (var i = 0; i < particles.length; i++) {
    var p = particles[i];

    isInside = false;

    if (p.x < textImg.width && p.y < textImg.height) {
      // Calculate the index for the pixels array from p.x and p.y
      var index = (floor(p.x) + floor(p.y) * textImg.width) * 4;
      // Get the red value from image
      var r = textImg.pixels[index];
      if (r < 128) {
        isInside = true;
      }
    }

    if (isInside) {
      p.diameter += (maxDiameter - p.diameter) * 0.05;
      //p.diameter = maxDiameter;
    } else {
      p.diameter += (minDiameter - p.diameter) * 0.03;
      //p.diameter = minDiameter;
    }

    fill(p.col);
    ellipse(p.x, p.y, p.diameter, p.diameter);

    p.y += p.vy;
    if (p.y > height) p.y = 0;
  }

}

function keyReleased() {
  // export png
  if (keyCode == CONTROL) saveCanvas(gd.timestamp(), 'png');
}

function keyPressed() {
  if (keyCode == DELETE || keyCode == BACKSPACE) {
    if (textTyped.length > 0) {
      textTyped = textTyped.substring(0, textTyped.length - 1);
      setupText();
    }
  } else if (keyCode == RETURN) {
    textTyped += "\n";
  }
}

function keyTyped() {
  if (keyCode >= 32) {
    textTyped += key;
    setupText();
  }
}