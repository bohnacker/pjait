/**
 * typo outline displayed as connecting lines
 *
 * KEYS
 * a-z                  : text input (keyboard)
 * backspace            : delete last typed letter
 * ctrl                 : save png
 */

var textTyped = "hello";

var font;
var path;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noLoop();

  opentype.load('data/FreeSans.otf', function(err, f) {
    if (err) {
      console.log(err);
    } else {
      font = f;
      loop();
    }
  });
}

function draw() {
  if (!font) return;

  background(0);
  // margin border
  translate(50, 300);

  if (textTyped.length > 0) {
    // get a path from OpenType.js
    var fontPath = font.getPath(textTyped, 0, 0, 300);
    // convert it to a g.Path object
    path = new g.Path(fontPath.commands);
    // resample it with equidistant points
    path = g.resampleByLength(path, mouseY / 50 + 10);
    // path = g.resampleByAmount(path, 500);

    // This might be the place to change things. From here ... ---------

    // draw connecting lines
    noFill();
    var maxD = mouseX / 5 + 10;

    for (var j = 0; j < path.commands.length; j++) {
      var pnt1 = path.commands[j];
      if (pnt1.x != undefined && pnt1.y != undefined) {

        for (var i = j + 1; i < path.commands.length; i++) {
          var pnt2 = path.commands[i];
          if (pnt2.x != undefined && pnt2.y != undefined) {

            // calculate the distance between pnt1 and pnt2
            var d = dist(pnt1.x, pnt1.y, pnt2.x, pnt2.y);

            if (d < maxD) {
              // calculate opacity from distance (the higher the distance, the lower the opacity)
              var opacity = maxD / d;
              stroke(255, 200, 30, d);
              line(pnt1.x, pnt1.y, pnt2.x, pnt2.y);
            }

          }
        }
      }
    }

    // ... to here -----------------------------------------------------
  }

}

function keyReleased() {
  // export png
  if (keyCode == CONTROL) saveCanvas(gd.timestamp(), 'png');
}

function keyPressed() {
  if (keyCode == DELETE || keyCode == BACKSPACE) {
    if (textTyped.length > 0) {
      textTyped = textTyped.substring(0, textTyped.length - 1);
    }
  }
}

function keyTyped() {
  if (keyCode >= 32) {
    textTyped += key;
  }
}