/**
 * typo outline displayed as connecting lines
 *
 * KEYS
 * a-z                  : text input (keyboard)
 * backspace            : delete last typed letter
 * ctrl                 : save png
 */

var textTyped = "hello";

var font;
var path;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noLoop();

  opentype.load('data/FreeSans.otf', function(err, f) {
    if (err) {
      console.log(err);
    } else {
      font = f;
      loop();
    }
  });
}

function draw() {
  if (!font) return;

  background(0);
  // margin border
  translate(50, 300);

  if (textTyped.length > 0) {
    // get a path from OpenType.js
    var fontPath = getPath(textTyped, 0, 0, 300, 300);
    // convert it to a g.Path object
    path = new g.Path(fontPath.commands);
    // resample it with equidistant points
    path = g.resampleByLength(path, mouseY / 50 + 10);
    // path = g.resampleByAmount(path, 500);

    // This might be the place to change things. From here ... ---------

    // draw connecting lines
    noFill();
    var maxD = mouseX / 5 + 10;

    for (var j = 0; j < path.commands.length; j++) {
      var pnt1 = path.commands[j];
      if (pnt1.x != undefined && pnt1.y != undefined) {

        for (var i = j + 1; i < path.commands.length; i++) {
          var pnt2 = path.commands[i];
          if (pnt2.x != undefined && pnt2.y != undefined) {

            // calculate the distance between pnt1 and pnt2
            var d = dist(pnt1.x, pnt1.y, pnt2.x, pnt2.y);

            if (d < maxD) {
              // calculate opacity from distance (the higher the distance, the lower the opacity)
              var opacity = maxD / d;
              stroke(255, 200, 30, d);
              line(pnt1.x, pnt1.y, pnt2.x, pnt2.y);
            }

          }
        }
      }
    }

    // ... to here -----------------------------------------------------
  }

}

function keyReleased() {
  // export png
  if (keyCode == CONTROL) saveCanvas(gd.timestamp(), 'png');
}

function keyPressed() {
  if (keyCode == DELETE || keyCode == BACKSPACE) {
    if (textTyped.length > 0) {
      textTyped = textTyped.substring(0, textTyped.length - 1);
    }
  } else if (keyCode == RETURN) {
    textTyped += "\n";
  }
}

function keyTyped() {
  if (keyCode >= 32) {
    textTyped += key;
  }
}

// Helper functions -------------------------------------------

// This function makes it possible to have line breaks in the text
function getPath(txt, x, y, txtSize, txtLeading) {
  var txtlines = txt.split(/[\n\r]+/);
  var fontPath = {};
  for (var i = 0; i < txtlines.length; i++) {
    var p = font.getPath(txtlines[i], x, y, txtSize);
    if (i == 0) {
      fontPath = p;
    } else {
      fontPath.commands = fontPath.commands.concat(p.commands);
    }
    y += txtLeading;
  }
  return fontPath;
}

// This function takes a path and breaks it into subpaths
// (It's not used in this template but could be very convenient in some cases)
function breakPath(path) {
  var subpaths = [];
  var subpath = [];
  for (var i = 0; i < path.commands.length; i++) {
    var type = path.commands[i].type;
    if (type == "Z") {
      subpaths.push(subpath);
      subpath = [];
    } else {
      subpath.push(path.commands[i]);
    }
  }
  return subpaths;
}