
// no need to change anything from here ... ----------------------

var letters = {};

var marginLeft = 20;
var marginTop = 50;
var textX = marginLeft;
var textY = 150;
var lineHeight = 120;
var typedText = "ABC";

function setup() {
	createCanvas(windowWidth, windowHeight);
	initLetters();
	noFill();
}

function draw() {
	background(255);
	scale(2);

	textX = marginLeft;
	textY = marginTop + 100;

	//randomSeed(4);
	for (var i = 0; i < typedText.length; i++) {
		var c = typedText[i];
		if (letters[c]) {
			push();
			translate(textX, textY);
			var w = letters[c]();
			textX += w;
			pop();
		} else if (c == "\n") {
			textX = marginLeft;
			textY += lineHeight;
		}
	}

	noLoop();
}

function keyTyped() {
	var k = key;
	if (!letters[k]) {
		k = k.toUpperCase();
	}
	if (letters[k]) {
		typedText += k;
	}

	loop();
}


function keyPressed() {
	if (keyCode == RETURN) {
		typedText += "\n";
	}
	if (keyCode == BACKSPACE || keyCode == DELETE) {
		if (typedText.length > 0) typedText = typedText.slice(0, -1);
	}
}

// ... to here -----------------------------------------------------

function initLetters() {
	letters = {
		A: draw_A,
		B: draw_B,
		C: draw_C,
		" ": function() { return 30 },
	};

	//console.log(letters);
}


function draw_A() {
	colorMode(HSB, 360, 100, 100);

	var h = random(360);
	stroke(h, 100, 70);

	var sw = random(0.2, 1.5);
	strokeWeight(sw);

	a = random(10, 30);
	a = round(a);

	for (var x = 0; x <= 70.01; x += 70 / a) {
		var x2 = map(x, 0, 70, 25, 45);
		line(x, 0, x2, -100);
	}

	return 80;
}

function draw_B() {
	colorMode(HSB, 360, 100, 100);
	noFill();

	var h = random(360);
	stroke(h, 100, 70);

	var sw = random(0.2, 1.5);
	strokeWeight(sw);

	a = random(7, 14);
	a = round(a);

	for (var x = 0; x <= 30.01; x += 30 / a) {
		line(x, 0, x, -100);
	}
	for (var d = 0; d <= 67.01; d += 67 / a) {
		arc(30, -67, d, d, radians(-90), radians(90));
	}
	for (var d = 0; d <= 67.01; d += 67 / a) {
		arc(30, -33, d, d, radians(-90), radians(90));
	}

	return 80;
}

function draw_C() {
	colorMode(HSB, 360, 100, 100);

	var h = random(360);
	stroke(h, 100, 70);

	var sw = random(0.2, 1.5);
	strokeWeight(sw);

	a = random(10, 30);
	a = round(a);

	for (var d = 0; d <= 100.01; d += 100 / a) {
//		arc(30, -67, d, d, radians(-90), radians(90));
		arc(45, -50, d, d, radians(90), radians(-90));
	}

	return 60;
}
