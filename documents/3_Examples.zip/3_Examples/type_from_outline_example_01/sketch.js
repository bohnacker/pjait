/**
 * typo outline displayed as rotating lines
 *
 * KEYS
 * a-z                  : text input (keyboard)
 * backspace            : delete last typed letter
 * ctrl                 : save png
 */

var textTyped = "ABC";

var font;
var path;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noLoop();

  opentype.load('data/FreeSans.otf', function(err, f) {
    if (err) {
      console.log(err);
    } else {
      font = f;
      loop();
    }
  });
}

function draw() {
  if (!font) return;

  background(0);
  // margin border
  translate(50, 300);

  if (textTyped.length > 0) {
    // get a path from OpenType.js
    var fontPath = getPath(textTyped, 0, 0, 300, 300);
    // convert it to a g.Path object
    path = new g.Path(fontPath.commands);
    // resample it with equidistant points
    path = g.resampleByLength(path, mouseY/50 + 2);
    // path = g.resampleByAmount(path, 500);

    // This might be the place to change things. From here ... ---------

    // draw rotating lines
    noFill();
    stroke(255, 40, 180);
    var radius = mouseX / 10;

    for (var i = 0; i < path.commands.length; i++) {
      var pnt = path.commands[i];

      // only if x and y are defined
      if (pnt.x != undefined && pnt.y != undefined) {
        push();
        translate(pnt.x, pnt.y);
        // calculate an angle from frame count and position on the screen
        var angle = radians(frameCount + pnt.x + pnt.y);
        rotate(angle);
        line(-radius, 0, radius, 0);
        pop();
      }
    }

    // ... to here -----------------------------------------------------

  }
}

function keyReleased() {
  // export png
  if (keyCode == CONTROL) saveCanvas(gd.timestamp(), 'png');
}

function keyPressed() {
  if (keyCode == DELETE || keyCode == BACKSPACE) {
    if (textTyped.length > 0) {
      textTyped = textTyped.substring(0, textTyped.length - 1);
    }
  } else if (keyCode == RETURN) {
    textTyped += "\n";
  }
}

function keyTyped() {
  if (keyCode >= 32) {
    textTyped += key;
  }
}


// Helper functions -------------------------------------------

// This function makes it possible to have line breaks in the text
function getPath(txt, x, y, txtSize, txtLeading) {
  var txtlines = txt.split(/[\n\r]+/);
  var fontPath = {};
  for (var i = 0; i < txtlines.length; i++) {
    var p = font.getPath(txtlines[i], x, y, txtSize);
    if (i == 0) {
      fontPath = p;
    } else {
      fontPath.commands = fontPath.commands.concat(p.commands);
    }
    y += txtLeading;
  }
  return fontPath;
}

// This function takes a path and breaks it into subpaths
// (It's not used in this template but could be very convenient in some cases)
function breakPath(path) {
  var subpaths = [];
  var subpath = [];
  for (var i = 0; i < path.commands.length; i++) {
    var type = path.commands[i].type;
    if (type == "Z") {
      subpaths.push(subpath);
      subpath = [];
    } else {
      subpath.push(path.commands[i]);
    }
  }
  return subpaths;
}