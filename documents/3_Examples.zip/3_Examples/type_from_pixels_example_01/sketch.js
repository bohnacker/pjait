/**
 * type using pixels of an invisibly draw text to draw a grid of dots 
 *
 * KEYS
 * a-z                  : text input (keyboard)
 * backspace            : delete last typed letter
 * ctrl                 : save png
 */

var textTyped = "ABC";

var font;
var fontSize = 250;
var textImg;

var pointDensity = 20;


function preload() {
  font = loadFont("data/FreeSansBold.ttf");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  rectMode(CENTER);
  setupText();
}

function setupText() {
  // create an offscreen graphics object to draw the text into
  textImg = createGraphics(width, height);
  textImg.pixelDensity(1);
  textImg.background(0);
  textImg.fill(255);
  textImg.textFont(font);
  textImg.textSize(fontSize)
  textImg.text(textTyped, 100, fontSize + 50);
  textImg.loadPixels();
}


function draw() {
  background(0);

  fill(255);
  noStroke();

  pointDensity = floor(mouseX / 10 + 2);
  var offX = frameCount % pointDensity;

  for (var x = offX; x < textImg.width; x += pointDensity) {
    for (var y = 0; y < textImg.height; y += pointDensity) {
      // Calculate the index for the pixels array from x and y
      var index = (floor(x) + floor(y) * textImg.width) * 4;
      // Get the red value from image
      var r = textImg.pixels[index];

      if (r > 128) {
        fill(100, random(200, 255), 100);
        rect(x, y, pointDensity, pointDensity);

      } else {

        // ellipse(x, y, 10, 10);

      }
    }
  }

}

function keyReleased() {
  // export png
  if (keyCode == CONTROL) saveCanvas(gd.timestamp(), 'png');
}

function keyPressed() {
  if (keyCode == DELETE || keyCode == BACKSPACE) {
    if (textTyped.length > 0) {
      textTyped = textTyped.substring(0, textTyped.length - 1);
      setupText();
    }
  }
}

function keyTyped() {
  if (keyCode >= 32) {
    textTyped += key;
    setupText();
  }
}