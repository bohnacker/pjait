// no need to change anything from here ... ----------------------

var letters = {};

var marginLeft = 20;
var marginTop = 50;
var textX = marginLeft;
var textY = 150;
var lineHeight = 120;
var typedText = "AAA";

function setup() {
	createCanvas(windowWidth, windowHeight, WEBGL);
	ortho(-width / 2, width / 2, -height / 2, height / 2);
	initLetters();
	fill(0);
	//stroke(0);

	noStroke();
}

function draw() {
	background(255);

	translate(-width / 2, -height / 2);
	scale(1);

	textX = marginLeft;
	textY = marginTop + 100;

	randomSeed(0);

	for (var i = 0; i < typedText.length; i++) {
		var c = typedText[i];
		if (letters[c]) {
			push();
			translate(textX, textY);

			// this part is for rotating each letter ---------------
			translate(50, -50, 0);
			//rotateX(radians((mouseY - height / 2) / random(2, 5)));
			rotateY(radians(frameCount));
			translate(-50, 50, 0);
			// -----------------------------------------------------

			var w = letters[c]();
			textX += w;
			pop();
		} else if (c == "\n") {
			textX = marginLeft;
			textY += lineHeight;
		}
	}

}

function keyTyped() {
	if (letters[key]) {
		typedText += key;
	}
	if (keyCode == RETURN) {
		typedText += "\n";
	}
	if (keyCode == BACKSPACE || keyCode == DELETE) {
		if (typedText.length > 1) typedText = typedText.slice(0, -1);
		console.log(typedText);
	}

}
// ... to here -----------------------------------------------------


function initLetters() {
	// Add your calls to the letter functions here

	letters = {
		A: draw_A,
		B: draw_B,
		C: draw_C,
		" ": function() { return 30 },
	};
}

// A function for each letter

function draw_A() {

	push();
	translate(20, 0, 30);
	rotate(radians(20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(100, 0, -30);
	rotate(radians(-20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(30, -40, 0);
	rect(0, -10, 60, 20);
	pop();

	return 110;
}

function draw_B() {

	rect(10, 0, 10, -100);
	arc(10, -67, 67, 67, radians(-90), radians(90));
	arc(10, -33, 67, 67, radians(-90), radians(90));

	return 50;
}

function draw_C() {

	arc(10, -33, 67, 67, radians(-90), radians(90));

	return 50;
}