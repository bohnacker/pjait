/**
 * typo outline displayed as dots
 *
 * KEYS
 * a-z                  : text input (keyboard)
 * backspace            : delete last typed letter
 * ctrl                 : save png
 */

var textTyped = "ABC";

var font;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noLoop();

  opentype.load('data/FreeSans.otf', function(err, f) {
    if (err) {
      console.log(err);
    } else {
      font = f;
      loop();
    }
  });
}

function draw() {
  if (!font) return;

  background(255);
  // margin border
  translate(20, 220);

  if (textTyped.length > 0) {
    // get a path from OpenType.js
    var fontPath = getPath(textTyped, 0, 0, 200, 200);
    // convert it to a g.Path object
    var path = new g.Path(fontPath.commands);
    // resample it with equidistant points
    path = g.resampleByLength(path, 5);
    // path = g.resampleByAmount(path, 20, true);

    // This might be the place to change things. From here ... ---------

    // draw dots
    fill(0);
    noStroke();
    var diameter = mouseX / 10;
    for (var i = 0; i < path.commands.length; i++) {
      var pnt = path.commands[i];
      ellipse(pnt.x, pnt.y, diameter, diameter);
    }

    // ... to here -----------------------------------------------------

  }
}

function keyReleased() {
  // export png
  if (keyCode == CONTROL) saveCanvas(gd.timestamp(), 'png');
}

function keyPressed() {
  if (keyCode == DELETE || keyCode == BACKSPACE) {
    if (textTyped.length > 0) {
      textTyped = textTyped.substring(0, textTyped.length - 1);
    }
  } else if (keyCode == RETURN) {
    textTyped += "\n";
  }
}

function keyTyped() {
  if (keyCode >= 32) {
    textTyped += key;
  }
}

// Helper functions -------------------------------------------

// This function makes it possible to have line breaks in the text
function getPath(txt, x, y, txtSize, txtLeading) {
  var txtlines = txt.split(/[\n\r]+/);
  var fontPath = {};
  for (var i = 0; i < txtlines.length; i++) {
    var p = font.getPath(txtlines[i], x, y, txtSize);
    if (i == 0) {
      fontPath = p;
    } else {
      fontPath.commands = fontPath.commands.concat(p.commands);
    }
    y += txtLeading;
  }
  return fontPath;
}

// This function takes a path and breaks it into subpaths
// (It's not used in this template but could be very convenient in some cases)
function breakPath(path) {
  var subpaths = [];
  var subpath = [];
  for (var i = 0; i < path.commands.length; i++) {
    var type = path.commands[i].type;
    if (type == "Z") {
      subpaths.push(subpath);
      subpath = [];
    } else {
      subpath.push(path.commands[i]);
    }
  }
  return subpaths;
}