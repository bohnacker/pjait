/**
 * scripted letters in 3d
 *
 * KEYS
 * a-z                  : text input (keyboard)
 * backspace            : delete last typed letter
 * ctrl                 : save png
 */


// usually no need to change anything from here ... ----------------------

var letters = {};

var marginLeft = 20;
var marginTop = 50;
var textX = marginLeft;
var textY = 150;
var lineHeight = 120;
var typedText = "ABC";

function setup() {
	createCanvas(windowWidth, windowHeight, WEBGL);
	ortho(-width / 2, width / 2, -height / 2, height / 2);
	initLetters();
	fill(0);
	//stroke(0);

	noStroke();
}

function draw() {
	background(255);

	translate(-width / 2, -height / 2);
	scale(1);

	textX = marginLeft;
	textY = marginTop + 100;

	randomSeed(0);

	for (var i = 0; i < typedText.length; i++) {
		var c = typedText[i];
		if (letters[c]) {
			push();
			translate(textX, textY);

			// this part is for rotating each letter ---------------
			translate(50, -50, 0);
			//rotateX(radians((mouseY - height / 2) / random(2, 5)));
			rotateY(radians(frameCount));
			translate(-50, 50, 0);
			// -----------------------------------------------------

			var w = letters[c]();
			textX += w;
			pop();
		} else if (c == "\n") {
			textX = marginLeft;
			textY += lineHeight;
		}
	}

}

function keyTyped() {
	var k = key;
	if (!letters[k]) {
		k = k.toUpperCase();
	}
	if (letters[k]) {
		typedText += k;
	}
}

function keyPressed() {
	if (keyCode == RETURN) {
		typedText += "\n";
	}
	if (keyCode == BACKSPACE || keyCode == DELETE) {
		if (typedText.length > 1) typedText = typedText.slice(0, -1);
	}
}

function keyReleased() {
  // export png
  if (keyCode == CONTROL) saveCanvas(gd.timestamp(), 'png');
}

// ... to here -----------------------------------------------------


function initLetters() {
	// Add your calls to the letter functions here

	letters = {
		A: draw_A,
		B: draw_B,
		C: draw_C,
		" ": function() { return 30 },
	};
}

// A function for each letter

function draw_A() {
	push();
	translate(20, 0, 30);
	rotate(radians(20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(100, 0, -30);
	rotate(radians(-20));
	rect(-10, -110, 20, 110);
	pop();

	push();
	translate(30, -40, 0);
	rect(0, -10, 60, 20);
	pop();

	return 110;
}

function draw_B() {
	push();
	translate(0, 0, -30);
	rect(10, 0, 20, -100);
	pop();

	push();
	translate(0, 0, 0);
	arc(30, -67, 67, 67, radians(-90), radians(90));
	pop();

	push();
	translate(0, 0, 30);
	arc(30, -33, 67, 67, radians(-90), radians(90));
	pop();

	return 100;
}

function draw_C() {
	push();
	translate(0, 0, -20);
	arc(43, -50, 100, 100, radians(90), radians(180));
	pop();

	push();
	translate(0, 0, 20);
	arc(43, -50, 100, 100, radians(180), radians(-90));
	pop();

	return 50;
}